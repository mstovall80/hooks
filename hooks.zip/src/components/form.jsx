import React from 'react';

const Form = (props) =>{
    const{inputs, setInputs} = props;

    const onChange = (e) =>{
        setInputs({
            ...inputs,
            [e.target.name]: e.target.value
        });
    };
    return(
        <form className="d-flexbox justify-content-center">
            <h1>Registration</h1>
            <div className="form-floating mb-3">
                <label  htmlFor="firstName"></label>
                <input onChange={onChange}  type="text" placeholder="First Name" name="firstName"/>
            </div>
            <div className="form-floating mb-3">
                <label htmlFor="lastName"></label>
                <input onChange={onChange} placeholder="Last Name"  type="text" name="lastName"/>
            </div>
            <div className="form-floating mb-3">
                <label htmlFor="email"></label>
                <input onChange={onChange} placeholder="Email"  type="text" name="email"/>
            </div>
            <div className="form-floating mb-3">
                <label htmlFor="password"></label>
                <input onChange={onChange} placeholder="Password"  type="password" name="password"/>
            </div>
            <div className="form-floating mb-3">
                <label htmlFor="confirmPassword"></label>
                <input onChange={onChange} placeholder="Confirm Pass"  type="password" name="confirmPassword"/>
            </div>
        </form>
    );
};
export default Form;